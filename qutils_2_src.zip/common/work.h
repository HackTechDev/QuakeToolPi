#ifndef WORK_H
#define WORK_H

void InitWork(int numwork,int print);

void NextWork(void);

void DoneWork(void);

#endif

