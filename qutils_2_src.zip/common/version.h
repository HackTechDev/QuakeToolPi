#ifndef VERSION_H
#define VERSION_H

#define VERSION "version 2"

#endif

